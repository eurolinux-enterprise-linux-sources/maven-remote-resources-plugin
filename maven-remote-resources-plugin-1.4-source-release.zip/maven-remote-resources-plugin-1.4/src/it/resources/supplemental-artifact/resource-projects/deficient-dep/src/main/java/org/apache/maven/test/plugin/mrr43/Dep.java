package org.apache.maven.test.plugin.mrr43;

/**
 * Hello world!
 *
 */
public class Dep
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
